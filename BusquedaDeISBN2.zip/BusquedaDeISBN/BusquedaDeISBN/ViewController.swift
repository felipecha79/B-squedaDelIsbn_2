//
//  ViewController.swift
//  BusquedaDeISBN
//
//  Created by Juan Felipe Chávez on 28/07/16.
//  Copyright © 2016 JuanFelipeChávez. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtvwResultados: UITextView!
    @IBOutlet weak var txtClaveIsbn: UITextField!
    @IBOutlet weak var lblTitulo: UILabel!
    @IBOutlet weak var lblPortada: UILabel!


    func sincrono(pISBN: String) throws {




        let urls =  "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + pISBN
        let url =  NSURL(string: urls)
        //let datos:NSData? =  NSData(contentsOfURL: url!)
        let datos = NSData(contentsOfURL: url!)

        if datos == nil{
             //txtvwResultados.text = "No se encontraron Datos. Esto puede ser porque el ISBN no existe o no tiene conexion de Internet persistente"

            let alertController = UIAlertController(title: "Error", message:"Se ha producido un error de comunicación.", preferredStyle: UIAlertControllerStyle.Alert)

            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

            self.presentViewController(alertController, animated: true, completion: nil)

        }else{

            //En esta parte mandaba antes el texto en crudo, aqui va a componer el texto para que traiga sólo lo que quiere.


           /* let texto =  NSString(data:datos!, encoding:NSUTF8StringEncoding)
            txtvwResultados.text = texto! as String */


            do{
                let json = try NSJSONSerialization.JSONObjectWithData(datos!, options: NSJSONReadingOptions.MutableContainers)

                let dico1 = json as! NSDictionary

                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                let dico2 = dico1["ISBN:" + pISBN] as! NSDictionary
                self.lblTitulo.text = dico2["title"] as! NSString as String
                }
                else{

                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)

                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                    self.presentViewController(alertController, animated: true, completion: nil)

                }

                let dico11 = json as! NSDictionary
                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico22 = dico11["ISBN:" + pISBN] as! NSDictionary
                    let ItemArray = dico22["authors"] as! NSArray

                    for item in ItemArray {
                            let nameArray  = item["name"]!
                            self.txtvwResultados.text = ("Autor: \(nameArray!)")
                    }
                }else{
                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)

                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                    self.presentViewController(alertController, animated: true, completion: nil)
                }


                let dico111 = json as! NSDictionary
                if (dico1["ISBN:" + pISBN] as? NSDictionary) != nil
                {
                    let dico222 = dico111["ISBN:" + pISBN] as! NSDictionary
                    if (dico222["cover"] as? NSDictionary) != nil
                        {
                            let dico333 = dico222["cover"] as! NSDictionary
                            self.lblPortada.text = dico333["small"] as! NSString as String
                    }else{
                        self.lblPortada.text = "No se encontro portada"
                        }
                }else{
                    let alertController = UIAlertController(title: "Sin resultados", message:"No existe el libro, favor de revisar la consulta.", preferredStyle: UIAlertControllerStyle.Alert)

                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                    self.presentViewController(alertController, animated: true, completion: nil)
                }

                
            }
            catch {

                let alertController = UIAlertController(title: "Error", message:"Se ha producido un error de datos en la lectura de Json.", preferredStyle: UIAlertControllerStyle.Alert)

                alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,handler: nil))

                self.presentViewController(alertController, animated: true, completion: nil)


            }



        }

    }

    /* Si queremos que funcione de manera asincrona (Sin esperar respuesta del servidor

    func asincrono()   {

        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:978-84-376-0494-7"
        let url = NSURL(string: urls)
        let sesion = NSURLSession.sharedSession()
        let bloque = { (datos: NSData?, resp : NSURLResponse?, error : NSError? ) -> Void in
            let texto = NSString(data: datos!, encoding:NSUTF8StringEncoding)
            print (texto!)
        }

        let dt = sesion.dataTaskWithURL(url!, completionHandler: bloque)
        dt.resume()
        print("antes o después")
        
    }
*/


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.



    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnLimpiar(sender: AnyObject) {

        txtClaveIsbn.text = ""
        
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool {
        if textField == txtClaveIsbn{
            do{
                try
                sincrono(txtClaveIsbn.text!)
                txtClaveIsbn.resignFirstResponder()
                return true
            }//End Do
            catch
            {
                txtvwResultados.text = "Se ha provocado un error"
                return false
            }//End Catch
        }//End if
        else
        {
            return false
        }

    }



}

